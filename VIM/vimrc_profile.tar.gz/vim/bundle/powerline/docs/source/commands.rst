**************************************
Powerline shell commands’ manual pages
**************************************

.. toctree::
   :maxdepth: 1
   :glob:

   commands/*
